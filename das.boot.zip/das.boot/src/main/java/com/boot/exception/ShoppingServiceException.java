package com.boot.exception;

public class ShoppingServiceException extends Exception {

	public ShoppingServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ShoppingServiceException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ShoppingServiceException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ShoppingServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ShoppingServiceException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
}
