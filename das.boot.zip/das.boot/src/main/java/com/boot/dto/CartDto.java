package com.boot.dto;

import java.util.ArrayList;
import java.util.List;

import com.boot.entity.Cart;

public class CartDto {
	private float totalPrice;
	private List<Cart> cartProduct=new ArrayList<Cart>();
	public float getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(float totalPrice) {
		this.totalPrice = totalPrice;
	}
	public List<Cart> getCartProduct() {
		return cartProduct;
	}
	public void setCartProduct(List<Cart> cartProduct) {
		this.cartProduct = cartProduct;
	}
	public CartDto(float totalPrice,List<Cart> cartProduct) {
		super();
		this.totalPrice=totalPrice;
		this.cartProduct=cartProduct;
	}
	public CartDto() {
		// TODO
	}
}
