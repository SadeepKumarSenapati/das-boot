package com.boot.dto;

public class ProductDto {
	private int productId;
	private String productname;
	private int userId;
	private float price;
	private String category;
	
	public ProductDto(int productId,String productname,int userId,float price,String category) {
		super();
		this.productId=productId;
		this.productname=productname;
		this.userId=userId;
		this.price=price;
		this.category=category;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
	
}
