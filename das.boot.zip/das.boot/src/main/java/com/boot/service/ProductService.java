package com.boot.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.boot.entity.Product;
import com.boot.exception.ProductDoesnotExistException;

@Service
public interface ProductService {
	List<Product> displayProductByName(String productName)throws ProductDoesnotExistException;
}
