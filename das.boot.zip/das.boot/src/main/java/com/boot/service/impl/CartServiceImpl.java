package com.boot.service.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.boot.controller.CartController;
import com.boot.dto.CartDto;
import com.boot.dto.ProductDto;
import com.boot.entity.Cart;
import com.boot.entity.Product;
import com.boot.entity.User;
import com.boot.exception.CartIsEmptyException;
import com.boot.exception.NegativeQuantityException;
import com.boot.exception.ProductDoesnotExistException;
import com.boot.exception.UserDoesnotExistException;
import com.boot.repository.CartRepository;
import com.boot.repository.ProductRepository;
import com.boot.repository.UserRepository;
import com.boot.service.CartService;

@Service
@Transactional
public class CartServiceImpl implements CartService {
	@Autowired
	ProductRepository productRepository;
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	CartRepository cartRepository;
	
	private static final Logger logger=LoggerFactory.getLogger(CartServiceImpl.class);
	
	@Override
	@Transactional
	public String addToTheCart(ProductDto productDto) throws ProductDoesnotExistException,UserDoesnotExistException{
		
		Cart cart=new Cart();
		
		List<Product> productsInCart=new ArrayList<Product>();
		
		Optional<Product> product=productRepository.findById(productDto.getProductId());
		Optional<User> user=userRepository.findById(productDto.getUserId());
		if (!product.isPresent()) {
			throw new ProductDoesnotExistException("Product doesn't exists");
		}
		if (!user.isPresent()) {
			throw new UserDoesnotExistException("User doesn't exists");
		}
		int flag=0;
		List<Cart> cartProducts=cartRepository.findByUser(productDto.getUserId());
		for (Cart cartObj : cartProducts) {
			Product p=cartObj.getItem().get(0);
			int productId=p.getProductId();
			if (productId==productDto.getProductId()) {
				flag=1;
				cart=cartObj;
			}
		}
		if (flag==0) {
			productsInCart.add(product.get());
			cart.setItem(productsInCart);
			cart.setUser(user.get());
			cart.setCartId(productDto.getUserId());
			cart.setQuantity(1);
			cartRepository.save(cart);
		}
		else {
			cart.setQuantity(cart.getQuantity()+1);
			cartRepository.save(cart);
		}
		String message="Product is Added Successfully";
		return message;
	}
	@Override
	@Transactional
	public String updateQuantity(int pid,int quantity,int userId) throws NegativeQuantityException,ProductDoesnotExistException {
		String message="";
		
		if (quantity<0) {
			throw new NegativeQuantityException("Quantity Shouldn't be Negative");
		}
		Cart cart=cartRepository.findByUserInCart(userId);
		System.out.println(cart);
		for (Product products : cart.getItem()) {
			if (products.getProductId()==pid) {
				cart.setQuantity(0);
				cartRepository.deleteById(pid);
				message="Product Was Deleted Successfully";
			}
			else {
				throw new ProductDoesnotExistException("Product Does Not Exists");
			}
		}
		return message;
	}
	@Override
	@Transactional
	public String deleteAll() {
		List<Cart> cartList= cartRepository.findAll();
		List<Product> productList=cartList.get(0).getItem();
		for (int i = 0; i <= productList.size(); i++) {
			cartList.get(i).setQuantity(0);
		}
		cartRepository.deleteAllProducts(productList);
		String message="All Products Deleted";
		return message;
	}
	@Override
	@Transactional
	public CartDto displayTheCart(int userId) throws UserDoesnotExistException, CartIsEmptyException {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	@Transactional
	public String deleteTheProduct(int pid, int userId) throws ProductDoesnotExistException {
		// TODO Auto-generated method stub
		return null;
	}
	
}
