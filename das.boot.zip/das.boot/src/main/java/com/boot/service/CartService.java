package com.boot.service;

import org.springframework.stereotype.Service;

import com.boot.dto.CartDto;
import com.boot.dto.ProductDto;
import com.boot.exception.CartIsEmptyException;
import com.boot.exception.NegativeQuantityException;
import com.boot.exception.ProductDoesnotExistException;
import com.boot.exception.UserDoesnotExistException;

@Service
public interface CartService {
	 
	String addToTheCart(ProductDto productDto) throws ProductDoesnotExistException,UserDoesnotExistException;
	 
	CartDto displayTheCart(int userId)throws UserDoesnotExistException,CartIsEmptyException ;
	
	String deleteTheProduct(int pid,int userId) throws ProductDoesnotExistException;
	
	String deleteAll();
	
	String updateQuantity(int pid,int quantity,int userId)throws NegativeQuantityException,ProductDoesnotExistException;
}
