package com.boot.entity;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("2")
public class Apparel extends Product {
	private String apparelType;
	private String brand;
	private String design;
	public String getApparelType() {
		return apparelType;
	}
	public void setApparelType(String apparelType) {
		this.apparelType = apparelType;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getDesign() {
		return design;
	}
	public void setDesign(String design) {
		this.design = design;
	}
	public Apparel(int productId, String productName, float price, String category, String apparelType, String brand,
			String design) {
		super(productId, productName, price, category);
		this.apparelType = apparelType;
		this.brand = brand;
		this.design = design;
	}
	@Override
	public String toString() {
		return "Apparel [apprealType=" + apparelType + ", brand=" + brand + ", design=" + design + "]";
	}
	public Apparel() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((apparelType == null) ? 0 : apparelType.hashCode());
		result = prime * result + ((brand == null) ? 0 : brand.hashCode());
		result = prime * result + ((design == null) ? 0 : design.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Apparel other = (Apparel) obj;
		if (apparelType == null) {
			if (other.apparelType != null)
				return false;
		} else if (!apparelType.equals(other.apparelType))
			return false;
		if (brand == null) {
			if (other.brand != null)
				return false;
		} else if (!brand.equals(other.brand))
			return false;
		if (design == null) {
			if (other.design != null)
				return false;
		} else if (!design.equals(other.design))
			return false;
		return true;
	}
	public Apparel(int productId, String productName, float price, String category) {
		super(productId, productName, price, category);
		// TODO Auto-generated constructor stub
	}
	
}
