package com.boot.entity;

import java.io.Serializable;

public class CartValue implements Serializable {
	private int id;
	private int cartId;
	
	public CartValue() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public CartValue(int id, int cartId) {
		super();
		this.id = id;
		this.cartId = cartId;
	}
	@Override
	public String toString() {
		return "CartValue [id=" + id + ", cartId=" + cartId + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result=1;
		result=prime*result + cartId;
		result=prime*result + id;
		return result;
	}
	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CartValue other = (CartValue) obj;
		if (cartId != other.cartId)
			return false;
		if (id != other.id)
			return false;
		return true;
	}
}
