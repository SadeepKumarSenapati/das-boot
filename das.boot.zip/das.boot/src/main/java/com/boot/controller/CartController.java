package com.boot.controller;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.boot.dto.ProductDto;
import com.boot.exception.NegativeQuantityException;
import com.boot.exception.ProductDoesnotExistException;
import com.boot.exception.UserDoesnotExistException;
import com.boot.service.CartService;

@RestController
@CrossOrigin(origins="*")
@RequestMapping("/cart")
public class CartController {
	@Autowired
	CartService cartService;
	
	private static final Logger logger= LoggerFactory.getLogger(CartController.class);
	
	@PostMapping("/")
	public Map<String,Object> addToCart(@RequestBody ProductDto productDto) 
	{
		Map<String,Object> map = new HashMap<String,Object>();
		
		try {
			String message = cartService.addToTheCart(productDto);
			map.put("httpStatusCode", 200);
			map.put("httpStatus", "getSuccess");
			map.put("body", message);
			map.put("success", true);
			map.put("error", false);
		} 
		catch (ProductDoesnotExistException e) {
			map.put("httpStatusCode", 400);
			map.put("httpStatus", "bad Request");
			map.put("message", "error Occured");
			map.put("success", false);
			map.put("error", true);
			map.put("ExceptionMessage", e.getMessage());
		}
		catch (UserDoesnotExistException e) {
			map.put("httpStatusCode", 400);
			map.put("httpStatus", "bad Request");
			map.put("message", "error Occured");
			map.put("success", false);
			map.put("error", true);
			map.put("ExceptionMessage", e.getMessage());
		}
		return map;
	}
	
	@PutMapping("/update")
	public Map<String,Object> updateQuantity(@RequestParam int pid,@RequestParam int quantity,int userId) throws NegativeQuantityException
	{
		Map<String,Object> map = new HashMap<String,Object>();
		
		try {
			String message = cartService.updateQuantity(pid,quantity,userId);
			map.put("httpStatusCode", 200);
			map.put("httpStatus", "getSuccess");
			map.put("body", message);
			map.put("success", true);
			map.put("error", false);
		} 
		catch (ProductDoesnotExistException e) {
			map.put("httpStatusCode", 400);
			map.put("httpStatus", "bad Request");
			map.put("message", "error Occured");
			map.put("success", false);
			map.put("error", true);
			map.put("ExceptionMessage", e.getMessage());
		}
		catch (NegativeQuantityException e) {
			map.put("httpStatusCode", 400);
			map.put("httpStatus", "bad Request");
			map.put("message", "error Occured");
			map.put("success", false);
			map.put("error", true);
			map.put("ExceptionMessage", e.getMessage());
		}
		return map;
	}
	@DeleteMapping("/deleteAll")
	public Map<String,Object> deleteAll()
	{
		Map<String,Object> map = new HashMap<String,Object>();
		
		
			String message = cartService.deleteAll();
			map.put("httpStatusCode", 200);
			map.put("httpStatus", "getSuccess");
			map.put("body", message);
			map.put("success", true);
			map.put("error", false);
		
		return map;
	}
	
}
