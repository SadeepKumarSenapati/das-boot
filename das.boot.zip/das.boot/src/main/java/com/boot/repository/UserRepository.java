package com.boot.repository;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.stereotype.Repository;

import com.boot.entity.User;

@Repository
public interface UserRepository extends JpaRepositoryImplementation<User, Integer> {

}
