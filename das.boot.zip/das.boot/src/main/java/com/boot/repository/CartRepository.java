package com.boot.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.stereotype.Repository;

import com.boot.entity.Cart;
import com.boot.entity.Product;

@Repository
@Transactional
public interface CartRepository extends JpaRepositoryImplementation<Cart, Integer> {
	
	@Query("select c from Cart c where c.user.userId=?1")
	public List<Cart> findByUser(int userId);
	
	@Query("select c from Cart c where c.cartId=?1")
	public List<Cart> findByUserId(int userId);
	
	@Query("select c from Cart c where c.user.userId=?1")
	public Cart findByUserInCart(int userId);
	
	@Modifying
	@Query(value = "delete from cart_item",nativeQuery = true)
	public void deleteAllProducts(List<Product> productList);
}
